<html>
<head>
<title>
EVALUATION PAGE
</title>

</head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: "Lato", sans-serif;
 
}

.sidenav {
  height: 100%;
  width: 180px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #303030;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 25px;
  color: white;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 160px; /* Same as the width of the sidenav */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

.topnav {
  overflow: hidden;
  background-color: White;
  height: 80px;
  width: 2000px;
}
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Float four columns side by side */
.column {
  float: left;
  width: 25%;
  padding: 0 10px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 -5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
}

/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #f1f1f1;
}
.div1{
float:left;
}
table {
  border-spacing: 0;
  width: 80%;
  border: 1px solid #ddd;

}

th, td {
  text-align: left;
  padding: 16px;
}

tr:nth-child(even) {
  background-color: #f2f2f2
}
.show {display: block;}

h5
{
   margin-left: 1%;
   float: left;
  position : relative;
}
.head img{
 margin-left: 3%;
 float:left;
} 

.f{
  margin-left: 1%;
   float: left;
}
.fa{
  margin-left: 2%;
   float: left;
}
.fss{
margin-left: 16%;
   float: left;
}

</style>

<body>
<div class="sidenav">
 <h1 style=color:white>  &nbsp;&nbsp;  &nbsp;Admin</h1>
<br><br>
   <a href="Home.php">Home</a>
   <a href="#FY">Assessment</a>
  <a href="Moderation.php">Moderation</a>
  <a href="#TY">All Course</a>
  

</div>

<div class="f">
<div class="main">

<div class="topnav">
<div class="head img">
<img src ="logo2.jpg" width="80" height="80"  style="margin-left:2%;"><br>
<h5>Sharad Institute of Technology, College of Engineering.</h5>


</div>
</div>

<br><div class="fss">
<p style="font-size:20px;"><b>Department of Artifical Intelligence and Data Science<b></p>
</div>
<br>
<br>

<meta charset="utf-8">
<title>per</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="div1">
<div class="box">
 <div class="percentage">
  <svg>
     <circle cx="70" cy="70" r="70"></circle>
     <circle cx="70" cy="70" r="70"></circle>
</svg>
<div class="number">
 <h2>20<span>%</span></h2>
</div>
</div>
<h4 >Total Faculty</h4>

</div>
<div class="div1">
<div class="box">
 <div class="percentage">
  <svg>
     <circle cx="70" cy="70" r="70"></circle>
     <circle cx="70" cy="70" r="70"></circle>
</svg>
<div class="number">
 <h2>20<span>%</span></h2>
</div>
</div>
<h4 >Total Completed</h4>

</div>
<div class="div1">
<div class="box">
 <div class="percentage">
  <svg>
     <circle cx="70" cy="70" r="70"></circle>
     <circle cx="70" cy="70" r="70"></circle>
</svg>
<div class="number">
 <h2>87<span>%</span></h2>
</div>
</div>
<h4 >Toal Pending</h4>

</div>
<div class="div1">
<div class="box">
 <div class="percentage">
  <svg>
     <circle cx="70" cy="70" r="70"></circle>
     <circle cx="70" cy="70" r="70"></circle>
</svg>
<div class="number">
 <h2>87<span>%</span></h2>
</div>
</div>
<h4 >Total Papers</h4>

</div>
</div>
</div>
<br>
</div>
<br>

&nbsp;&nbsp;<a href="display(AIDS).php" ><p ><button onclick="sortTable()" style="float:left;margin-left:2%;height:35px;width:90px;border-radius:25px;background:blue;color:white;" ><b>Faculty</b></button></p></a>

 <a href="status(AIDS).php" ><p ><button onclick="sortTable()" style="float:left;margin-left:2%;height:35px;width:120px;border-radius:25px;background:blue;color:white;" ><b>Evaluator Status</b></button></p></a>




<br>
<br>
<br><center></center>
<br>
<a href="https://docs.google.com/spreadsheets/d/1a-SX-CkGdk8LPZSvYWwQMHBVyH8h8XCmjNfBrPjDviQ/edit?usp=sharing" ><button style="float:left;margin-left:2%;height:35px;width:90px;border-radius:25px;background:blue;color:white;" ><b>Sheet</b></button></a>

<button></button>

<br>


</body>
</html> 

