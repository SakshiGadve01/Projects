<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="main.css">
    <link href="mailer.js">

    <title>SITCOE Evaluation System</title>
    </head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    body {
      font-family: "Lato", sans-serif;
     
    }
    
    .sidenav {
      height: 100%;
      width: 180px;
      position: fixed;
      z-index: 1;
      top: 0;
      left: 0;
      background-color: #303030;
      overflow-x: hidden;
      padding-top: 20px;
    }
    
    .sidenav a {
      padding: 6px 8px 6px 16px;
      text-decoration: none;
      font-size: 25px;
      color: white;
      display: block;
    }
    
    .sidenav a:hover {
      color: #f1f1f1;
    }
    
    .main {
      margin-left: 160px; /* Same as the width of the sidenav */
      font-size: 28px; /* Increased text to enable scrolling */
      padding: 0px 10px;
    }
    
    @media screen and (max-height: 450px) {
      .sidenav {padding-top: 15px;}
      .sidenav a {font-size: 18px;}
    }
    
    .topnav {
      overflow: hidden;
      background-color: White;
      height: 80px;
      width: 2000px;
    }
    * {
      box-sizing: border-box;
    }
    
    body {
      font-family: Arial, Helvetica, sans-serif;
    }
    
    /* Float four columns side by side */
    .column {
      float: left;
      width: 25%;
      padding: 0 10px;
    }
    
    /* Remove extra left and right margins, due to padding */
    .row {margin: 0 -5px;}
    
    /* Clear floats after the columns */
    .row:after {
      content: "";
      display: table;
      clear: both;
    }
    
    /* Responsive columns */
    @media screen and (max-width: 600px) {
      .column {
        width: 100%;
        display: block;
        margin-bottom: 20px;
      }
    }
    
    /* Style the counter cards */
    .card {
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
      padding: 16px;
      text-align: center;
      background-color: #f1f1f1;
    }
    .div1{
    float:left;
    }
    
    
    </style>
    <body>
      <div class="sidenav">
        <h1 style=color:white>&nbsp;&nbsp;&nbsp;Admin</h1>
       <br>
         <a href="Home.php">Home</a>
         <a href="#FY">Assessment</a>
  		 <a href="Moderation.php">Moderation</a>
  		 <a href="#TY">All Course</a>
       
       </div>
       <div class="f">
       <div class="main">
       
    <header>
        <div class="hd">
        <img src="clg.png" style=" position: absolute; width: 86px;
        height: 81px;
        left: 60px;
        top: 10px"></img>
        
<h2>Sharad Institute of Technology College Of Engineering,Yadrav</h2>
        </div>
    </header>
  <body>
    <!--<div class="box1">
    </div>-->
    <div class="search1">

    </div>
    <div class="sea">
    </div>
    <div class="box2"></div><br>
    <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>
    <div class="visitor"> 
     <div class="CSE">
      <a href="Eval(CSE).php">Computer Science and Engineering</a>
      </div>
      <div class="AIDS">
        <a href="Eval(AIDS).php">Artifial Intelligence and <br>Data Science</a>
      </div>
      <div class="ETC">
         <a href="Eval(ECE).php">Electronics and Telecommunication</a>
      </div>
      <div class="MECH">
        <a href="Eval(ME).php">Mechanical <br>Engineering </a></div>
       <div class="CESA">
        <a href="Eval(CE).php">Civil <br>Engineering</a></div>
        <div class="MECH2">
        <a href="Eval(MEE).php">Mechatronics<br> Engineering</a></div>
        <div class="ELEC">
        <a href="Eval(EE).php">Electrical <br>Engineering</a></div>
        <div class="RA">
        <a href="Eval(RAE).php">Robotics and Automation<br> Engineering</a></div>
    </div>
    <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  
    <div class="visitor2"> </div>

    </body>
    <h4>SITCOE Evaluation Status Reminder System</h4>
</body>
</html>