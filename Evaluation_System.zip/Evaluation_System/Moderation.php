<!DOCTYPE html>
<html lang="en" dir="ltr">

	<head>
		<meta charset="utf-8">
		<title>Moderation</title>
		<link rel="stylesheet" href="stylemod.css">
		<style>
			hr {
  height: 2px;
  background-color: #FF0000;
  border: none;
}
</style>
	</head>
	 <body style="background-color:#89CFF0;">
		<div class="hd">
        <img src="clg.png" 
		style=" position: absolute; 
		width: 86px;
		height: 81px;
		left: 40px;
		top: 15px"></img>
<h2 style="color: black"><center>Shri Shamrao Patil (Yadravkar) Educational & Charitable Trust’s</center></h2>
<h1 style="color: black"><center>Sharad Institute of Technology College Of Engineering,Yadrav</center></h1><hr>
        </div><h1   style="color: black"><center>Moderation</center></h1><br><br>
		<center><a href="#" class="btn" style="color: black">Available For Assessment</a>
		<a href="#" class="btn" style="color: black">Assessment Completed</a><br><br><br><br><br>
		<a href="#" class="btn" style="color: black">Available For Moderation</a>
		<a href="#" class="btn" style="color: black">Moderation Completed</a></center><br><br><br><br><br>
		
	</body> 
</html>