<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="Registration.css" />
  <title>Form</title>
</head>

<body>
  <div class="hd">
        <img src="clg.png" 
		style=" position: absolute; 
		width: 86px;
		height: 81px;
		left: 40px;
		top: 15px"></img>
<h2 style="color: black"><center>Shri Shamrao Patil (Yadravkar) Educational & Charitable Trust’s</center></h2>
<h1 style="color: black"><center>Sharad Institute of Technology College Of Engineering,Yadrav</center></h1>
        </div><br><hr>
  <div class="login-wrap">
    <div class="login-html">
      <input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Login</label>
      <input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Register</label>
      <div class="login-form">
        <div class="sign-in-htm">
          <div class="group">
            <label for="user" class="label">Username</label>
            <input id="user" type="text" class="input">
          </div>
          <div class="group">
            <label for="pass" class="label">Password</label>
            <input id="pass" type="password" class="input" data-type="password">
          </div>
          <div class="group">
            <input id="check" type="checkbox" class="check" checked>
            <label for="check"><span class="icon"></span> Keep me Signed in</label>
          </div>
          <div class="group">
            <a href="Home.html"><input type="submit" class="button" value="Login">
          </div>
          <div class="hr"></div>
          <div class="foot-lnk">
            <a href="#forgot">Forgot Password?</a>
          </div>
        </div>

        <div class="sign-up-htm">
	 <div class="group">
            <label for="name" class="label">Full  Name</label>
            <input id="name" type="text" class="input">
          </div>
	 <div class="group">
            <label for="phone" class="label">Mobile  Number</label>
            <input type="tel" id="phone" name="phone" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" required class="input">
          </div>
	 <div class="group">
            <label for="pass" class="label">Email  Address</label>
            <input id="pass" type="text" class="input">
          </div>
	 <div class="group">
            <label for="user" class="label">Username</label>
            <input id="user" type="text" class="input">
          </div>
          <div class="group">
            <label for="pass" class="label">Password</label>
            <input id="pass" type="password" class="input" data-type="password">
          </div>
          <div class="group">
            <label for="pass" class="label">Confirm  Password</label>
            <input id="pass" type="password" class="input" data-type="password">
          </div>   
          <div class="group">
            <input type="submit" class="button" value="Submit">
          </div>
          <div class="hr"></div>
          <div class="foot-lnk">
            <label for="tab-1">Already Member?</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>

</html>