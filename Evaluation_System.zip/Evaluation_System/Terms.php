<!DOCTYPE html>
<html>
<head>
  <title>Terms and Condition Section </title>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>

<div class="wrapper flex_align_justify">
   <div class="tc_wrap">
       <div class="tabs_list">
         <ul>
           <li data-tc="tab_item_1" class="active">About Our Services</li>
           <li data-tc="tab_item_2">Privacy Policy</li>
           <li data-tc="tab_item_3">Data Policy</li>
           
         </ul>
       </div>
       <div class="tabs_content">
          <div class="tab_head">
            <h2>Terms & Conditions</h2>
          </div>
          <div class="tab_body">
            <div class="tab_item tab_item_1">

                <h3>About Our Services</h3>
             <p>Since we started this system, we've built our Services with strong privacy and security principles in mind.  </p>
            </div>

	<div class="tab_item tab_item_2">
	<h3> Privacy Policy</h3>
	<p> We work to protect the safety, security, and integrity of our Services. This includes appropriately dealing with the customers who are violating our Terms. We work to prohibit misuse of our Services.</p>
            	</div>

	<div class="tab_item tab_item_3">
	<h3> Data Policy</h3>
	<p> Please Enter the accurate information.</p>
            	</div>
	
           
          </div>
          <div class="tab_foot flex_align_justify">
            <button class="decline">
              Decline
            </button>
            <button class="agree">
              Agree
            </button>
          </div>
       </div>
   </div>
</div>

<script type="text/javascript" src="scripts.js"></script>

</body>
</html>