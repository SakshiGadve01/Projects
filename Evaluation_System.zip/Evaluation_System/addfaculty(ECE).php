<!DOCTYPE html>
<html>
<head>
<title>
ADD NEW FACULTY
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  
 background-color: grey;
  
}


* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: white;
  margin-left:300px;
 margin-right:300px;
 margin-top:100px;

}

/* Full-width input fields */
input[type=text], input[type=password] ,input[type=number] ,input[type=email] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #002ead;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 50%;
  opacity: 0.9;
  transition: 0.7s;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: gray;
  text-align: center;
}
h1
{
color: red;}
function validationform(){
var x= document.forms["myforms"]["Registraction no"].value,["fn"].value;
if(x == ""){
alert("PLZ fill the unfield field to submit ur form");
return ;
}
}

</style>
</head>
<body>
<form name="myform" onsubmit="return validationform()" method="post">
  <div class="container">
    <h1>Add Faculty </h1>
    <p>Please fill in this form </p>
    <hr>

    <label for="Name_of_Faculty"><b>Name Of Faculty</b></label>
    <input type="text" placeholder="Enter Name of Faculty" name="Name_of_Faculty" id="Name_of_Faculty" required>

    <label for="Department"><b>Department</b></label>
    <input type="text" placeholder="Enter Department" name="Department" id="Department" required>

    <label for="Email_ID  "><b>Email_ID</b></label>
    <input type="text" placeholder="Enter Email_ID" name="Email_ID " id="Email_ID  " required>
  
   
    <label for="Mobile_Number"><b>Mobile Number</b></label>
    <input type="text" maxlength="10" minlength="10" placeholder="Enter Mobile Number" name="Mobile_Number" id="Mobile_Number" required>   
   
   
     

    <hr>
    <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
    <center>
    <a href="Eval(ECE).php" style="color : black;"><button type="submit" name="sb" class="registerbtn" style="border-radius:25px;"> ADD</button></a><br><br>
      
</center>
  </div>
 
</form>
<br>

<center>
 <a href="Eval(ECE).html" align="right" style="color:black;" ><button style="height:50px;width:90px;border-radius:25px;background:white;"> BACK</button><a>
 </center>
 <?php

 $con=mysqli_connect('localhost','root','','evaluation_system');
 if(isset($_POST['sb']))
 {
  $f = $_POST['Name_of_Faculty'];
  $e = $_POST['Email_ID'];
  $d = $_POST['Department'];
  $m = $_POST['Mobile_Number'];

    $query = "INSERT INTO addfacultyece(Name_of_Faculty,Email_ID,Department,Mobile_Number)VALUES('$f','$e','$d','$m')";
    $run = mysqli_query($con,$query);
 }
 ?>
</body>
</html>
