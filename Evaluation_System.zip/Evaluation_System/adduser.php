
<!DOCTYPE html>
<html>
<head>
<title>
ADD NEW FACULTY
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  
 background-color: grey;
  
}


* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: white;
  margin-left:300px;
 margin-right:300px;
 margin-top:100px;

}

/* Full-width input fields */
input[type=text], input[type=password] ,input[type=number] ,input[type=email] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #002ead;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 50%;
  opacity: 0.9;
  transition: 0.7s;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: gray;
  text-align: center;
}
h1
{
color: red;}
function validationform(){
var x= document.forms["myforms"]["Registraction no"].value,["fn"].value;
if(x == ""){
alert("PLZ fill the unfield field to submit ur form");
return ;
}
}

</style>

</head>
<body>
<form name="myform" onsubmit="return validationform()" method="post" >
  <div class="container">
    <h1>Add Faculty </h1>
    <p>Please fill in this form </p>
    <hr>

    <label for="name"><b>Name Of Faculty</b></label>
    <input type="text" placeholder="Enter Name of Faculty" name="Faculty" id="Faculty" required>

    <label for="dep"><b>Department</b></label>
    <input type="text" placeholder="Enter Department" name="dep" id="dep" required>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" id="email" required>
  
   
    <label for="ln"><b>Phone Number</b></label>
    <input type="text" maxlength="10" minlength="10" placeholder="Enter Phone Number" name="ln" id="ln" required>

   
    <label for="paper"><b>Number of Papers</b></label>
    <input type="text" placeholder="Enter Number of Papers" name="paper" id="paper" required>

     

    <hr>
    <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
    <center>
    <a href="Eval(CSE).php" style="color : black;"><button type="submit" name="sb" class="registerbtn" style="border-radius:25px;" > ADD</button></a><br><br>
      
</center>
  </div>
 
</form>
<br>

<center>
 <a href="Eval(CSE).php" align="right" style="color:black;" ><button style="height:50px;width:90px;border-radius:25px;background:white;"> BACK</button><a>
 </center>
 <?php

 $con=mysqli_connect('localhost','root','','evaluation_system');
 if(isset($_POST['sb']))
 {
 	$f = $_POST['Faculty'];
 	$d = $_POST['dep'];
 	$e = $_POST['email'];
 	$p = $_POST['ln'];
    $n = $_POST['paper'];
    $query = "INSERT INTO adduser(Faculty,dep,email,ln,paper)VALUES('$f','$d','$e','$p','$n')";
    $run = mysqli_query($con,$query);
 }
 ?>
</body>
</html>
