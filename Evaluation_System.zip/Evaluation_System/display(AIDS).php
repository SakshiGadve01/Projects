<?php
  include 'connect.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<title>Data Display</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>

<div class="container">
	<a href="addfaculty(AIDS).php"><button type="button" class="btn btn-primary my-5">Add Faculty</button></a>
  
  
	<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Sr no</th>
      <th scope="col">Name of Faculty</th>
      <th scope="col">Email_ID</th>
      <th scope="col">Department</th>
      <th scope="col">Mobile Number</th>
      <th scope="col">Operations</th>
    </tr>
  </thead>
  <tbody>
  	<?php
         $sql = "Select * from addfacultyaids ";
         $result = mysqli_query($con,$sql);
         if($result){
         	while($row=mysqli_fetch_assoc($result)){
         		$ID=$row['ID'];
         		$Name_of_Faculty=$row['Name_of_Faculty'];
         		$Email_ID=$row['Email_ID'];
         		$Department=$row['Department'];
         		$Mobile_Number=$row['Mobile_Number'];
         		echo '
         		<tr>
      				<th scope="row">'.$ID.'</th>
      				<td>'.$Name_of_Faculty.'</td>
      				<td>'.$Email_ID.'</td>
      				<td>'.$Department.'</td>
      				<td>'.$Mobile_Number.'</td>
      				<td>
      				<a href="update.php?updateid='.$ID.'" class="text-light"><button class="btn btn-primary">Update</button></a>
      				<a href="delete.php?deleteid='.$ID.'" class="text-light"><button class="btn btn-danger">Delete</button></a>
      				</td>

    			</tr>';
         	}
         	
         }

  	?>
   



  </tbody>
</table>


</div>
</body>
</html>