-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 19, 2023 at 08:36 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `evaluation_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `addfacultyaids`
--

CREATE TABLE `addfacultyaids` (
  `id` int(255) NOT NULL,
  `Name_of_Faculty` varchar(255) NOT NULL,
  `Email_ID` varchar(255) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Mobile_Number` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `addfacultyce`
--

CREATE TABLE `addfacultyce` (
  `id` int(255) NOT NULL,
  `Name_of_Faculty` varchar(255) NOT NULL,
  `Email_ID` varchar(255) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Mobile_Number` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `addfacultycse`
--

CREATE TABLE `addfacultycse` (
  `id` int(255) NOT NULL,
  `Name_of_Faculty` varchar(255) NOT NULL,
  `Email_ID` varchar(255) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Mobile_Number` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addfacultycse`
--

INSERT INTO `addfacultycse` (`id`, `Name_of_Faculty`, `Email_ID`, `Department`, `Mobile_Number`) VALUES
(1, 'Dr.S.B.Gurav', 'sb@gmail.com', 'AIDS', '1111111111');

-- --------------------------------------------------------

--
-- Table structure for table `addfacultyece`
--

CREATE TABLE `addfacultyece` (
  `id` int(255) NOT NULL,
  `Name_of_Faculty` varchar(255) NOT NULL,
  `Email_ID` varchar(255) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Mobile_Number` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `addfacultyee`
--

CREATE TABLE `addfacultyee` (
  `id` int(255) NOT NULL,
  `Name_of_Faculty` varchar(255) NOT NULL,
  `Email_ID` varchar(255) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Mobile_Number` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `addfacultyme`
--

CREATE TABLE `addfacultyme` (
  `id` int(255) NOT NULL,
  `Name_of_Faculty` varchar(255) NOT NULL,
  `Email_ID` varchar(255) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Mobile_Number` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `addfacultymee`
--

CREATE TABLE `addfacultymee` (
  `id` int(255) NOT NULL,
  `Name_of_Faculty` varchar(255) NOT NULL,
  `Email_ID` varchar(255) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Mobile_Number` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `addfacultyrae`
--

CREATE TABLE `addfacultyrae` (
  `id` int(255) NOT NULL,
  `Name_of_Faculty` varchar(255) NOT NULL,
  `Email_ID` varchar(255) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Mobile_Number` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `user_name`, `password`) VALUES
(1, 'admin@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `statuscse`
--

CREATE TABLE `statuscse` (
  `id` int(255) NOT NULL,
  `Name_of_Faculty` varchar(255) NOT NULL,
  `Email_ID` varchar(255) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Mobile_Number` varchar(10) NOT NULL,
  `Total_Papers` int(255) NOT NULL,
  `No_of_Completed` int(255) NOT NULL,
  `No_of_Pending` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `statuscse`
--

INSERT INTO `statuscse` (`id`, `Name_of_Faculty`, `Email_ID`, `Department`, `Mobile_Number`, `Total_Papers`, `No_of_Completed`, `No_of_Pending`) VALUES
(1, 'Dr.S.B.Gurav', 'sb@gmail.com', 'CSE', '1111111111', 100, 70, 30);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addfacultyaids`
--
ALTER TABLE `addfacultyaids`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addfacultyce`
--
ALTER TABLE `addfacultyce`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addfacultycse`
--
ALTER TABLE `addfacultycse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addfacultyece`
--
ALTER TABLE `addfacultyece`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addfacultyee`
--
ALTER TABLE `addfacultyee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addfacultyme`
--
ALTER TABLE `addfacultyme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addfacultymee`
--
ALTER TABLE `addfacultymee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addfacultyrae`
--
ALTER TABLE `addfacultyrae`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `statuscse`
--
ALTER TABLE `statuscse`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addfacultyaids`
--
ALTER TABLE `addfacultyaids`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `addfacultyce`
--
ALTER TABLE `addfacultyce`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `addfacultycse`
--
ALTER TABLE `addfacultycse`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `addfacultyece`
--
ALTER TABLE `addfacultyece`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `addfacultyee`
--
ALTER TABLE `addfacultyee`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `addfacultyme`
--
ALTER TABLE `addfacultyme`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `addfacultymee`
--
ALTER TABLE `addfacultymee`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `addfacultyrae`
--
ALTER TABLE `addfacultyrae`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `statuscse`
--
ALTER TABLE `statuscse`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
