 <?php

 $con=mysqli_connect('localhost','root','','evaluation_system') or die("Connection Failed");
 
  $user_name = $_POST['user_name'];
  $password = $_POST['password'];
 
  $user_name = stripcslashes($user_name);
   $password = stripcslashes($password);

   $user_name = mysqli_real_escape_string($con,$user_name);
   $password = mysqli_real_escape_string($con,$password);


    $query = "Select * from login where user_name='$user_name' and password='$password'";
    $r= mysqli_query($con,$query);
    $row = mysqli_fetch_array($r,MYSQLI_ASSOC);
    $count =mysqli_num_rows($r);

    if($count==1)
    {
        echo "<script> window.location.assign('Index.php');</script>";
    }
    else
    {
        echo "LOGIN  NOT SUCCESFUL";
    }
  
 
 ?>