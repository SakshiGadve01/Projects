<?php
  include 'connect.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<title>Data Display</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">

</head>
<body>

<div class="container">
	<a href="addstatus(CSE).php"><button type="button" class="btn btn-primary my-5">Add Evaluator</button></a>
  
  
	<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Sr no</th>
      <th style="width:20% " scope="col">Name of Faculty</th>
      <th style="width:20% " scope="col">Email_ID</th>
      <th style="width:20% " scope="col">Department</th>
      <th style="width:20% " scope="col">Mobile Number</th>
      <th style="width:20% " scope="col">Total Papers</th>
      <th style="width:20% " scope="col">No. of Completed</th>
      <th style="width:20% " scope="col">No. of Pending</th>
      <th style="width:20% " scope="col" ><center>Operations</center></th>
    </tr>
  </thead>
  <tbody>
  	<?php
         $sql = "Select * from statuscse ";
         $result = mysqli_query($con,$sql);
         if($result){
         	while($row=mysqli_fetch_assoc($result)){
         		$ID=$row['id'];
         		$Name_of_Faculty=$row['Name_of_Faculty'];
         		$Email_ID=$row['Email_ID'];
         		$Department=$row['Department'];
         		$Mobile_Number=$row['Mobile_Number'];
            $Total_Papers=$row['Total_Papers'];
            $No_of_Completed=$row['No_of_Completed'];
            $No_of_Pending=$row['No_of_Pending'];
         		echo '
         		<tr>
      				<th scope="row">'.$ID.'</th>
      				<td>'.$Name_of_Faculty.'</td>
      				<td>'.$Email_ID.'</td>
      				<td>'.$Department.'</td>
      				<td>'.$Mobile_Number.'</td>
              <td>'.$Total_Papers.'</td>
              <td>'.$No_of_Completed.'</td>
              <td>'.$No_of_Pending.'</td>
      				<td>

      				  <a href="statuscse(update).php?updateid='.$ID.'" class="text-light" >
                   <button style="margin-right:200px;" class="btn btn-primary">Update</button>
                </a> 
                <a href="statuscse(delete).php?deleteid='.$ID.'" class="text-light" >
                   <button class="btn btn-danger">Delete</button>
                </a> 
                <a href="dele.php?deleteid='.$ID.'" class="text-light"><img src="not2.png" style="height:50px;width=240px;"></a>
  
      				</td>

    			    </tr>';
         	}
         	
         }

  	?>
              



  </tbody>
</table>


</div>
</body>
</html>