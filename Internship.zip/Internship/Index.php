<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SIT Internship</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/fontawesome/css/all.css">
    <link rel="stylesheet" href="style(mainpage).css">
  </head>
  <body>
    <center>
    <div class="card mb-3" style="max-width: 1500px;" id="tit1">
        <div class="row g-0">
          <div class="col-md-4">
            <img src="logo.png" class="img-fluid rounded-start" alt="..."id="img1" style="background-color: orange;">
          </div>
          <div class="col-md-8">
            <div class="card-body">
              <h5 class="card-title">SHARAD INSTITUTE OF TECHNOLOGY COLLEGE OF ENGINEERING</h5>
              <p class="card-text">An Autonomous Institute 
                NBA Accredited Programmes. An ‘A’ Grade Institute Accredited By NAAC, An ISO 9001:2015 Accredited Institute.  
                Recognized u/s 2(f) & 12(B) Of The UGC Act 1956</p>
            </div>
          </div>
        </div>
      </div></center>
   <!--<section id="navigation">
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid"  id="navid"  style="width: 300px; align-self: center;">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav">
              <a class="nav-link" href="#">Home</a>
              <a class="nav-link" href="#">Login</a>
              <a class="nav-link" href="#">Register</a>
            </div>
          </div>
        </div>
      </nav>
    </section>-->
    <section id="main" class="mt-5">
        <div class="comtainer" id="cont">
            <div class="row">
              <div class="col-sm-3 my-2">
                <div class="card mx-5" style="width: 18rem; height: 15rem;">
                    <img src="cse.jpg" class="card-img-top" alt="..." width="25" height="150">
                    <div class="card-body">
                      <a href="CSE.php" class="btn btn-primary">Computer Science & Engineering</a>
                    </div>
                </div>
            </div>
                <div class="col-sm-3 my-2">
                  <div class="card mx-5" style="width: 18rem; height: 15rem;">
                      <img src="ai.webp" class="card-img-top" alt="..." width="25" height="150">
                      <div class="card-body">
                        <a href="aids.php" class="btn btn-primary">Artificial Intellegence & Data Science</a>
                      </div>
                  </div>
              </div>
        
                <div class="col-sm-3 my-2">
                  <div class="card mx-5" style="width: 18rem; height: 15rem;">
                      <img src="electron.jpg" class="card-img-top" alt="..." width="25" height="150">
                      <div class="card-body">
                        <a href="elec.php" class="btn btn-primary">Electronics and Computer Engineering</a>
                      </div>
                  </div>
              </div>
                <div class="col-sm-3 my-2">
                    <div class="card mx-5" style="width: 18rem; height: 15rem;">
                        <img src="mech.jpg" class="card-img-top" alt="..." width="25" height="150">
                        <div class="card-body">
                          <a href="mech.php" class="btn btn-primary">Mechanical Engineering</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <div class="comtainer">
            <div class="row">
                <div class="col-sm-3 my-2" >
                    <div class="card mx-5" style="width: 18rem;">
                        <img src="electric.jpg" class="card-img-top" alt="..." width="25" height="150">
                        <div class="card-body">
                          <a href="elec.php" class="btn btn-primary">Electrical Engineering</a>
                        </div>
                    </div>
                </div>
                
                <div class="col-sm-3 my-2">
                <div class="card mx-5" style="width: 18rem;">
                        <img src="mecha.jpg" class="card-img-top" alt="..." width="25" height="150">
                        <div class="card-body">
                          <a href="mechtro.php" class="btn btn-primary">Mechatronics Engineering</a>
                        </div>
                    </div>
                </div>
        
                <div class="col-sm-3 my-2">
                    <div class="card mx-5" style="width: 18rem;">
                        <img src="robo.jpg" class="card-img-top" alt="..."width="25" height="150">
                        <div class="card-body">
                          <a href="robo.php" class="btn btn-primary">Automation & Robotics</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 my-2">
                  <div class="card mx-5" style="width: 18rem;">
                      <img src="civil.jpg" class="card-img-top" alt="..."width="25" height="150">
                      <div class="card-body">
                        <a href="civil.php" class="btn btn-primary">Civil Engineering</a>
                      </div>
                  </div>
              </div>
            </div>
        </div>
        </div>
      </section>
      <footer id="footer" class="mt-5">
        <div class="row">
          <div class="col-sm-4">
            <div class="footer-about">
              <h1>About SITCOE</h1>
              <p>Late Shamrao Patil (Yadravkar) was the founder of Shri. Shamrao Patil (Yadravkar) Educational & Charitable Trust, Jaysingpur Dist-Kolhapur. He was a great Social Worker of Yadrav and Jaysingpur area, who tried to help farmers and poor backward people of their upliftment.
              
              </p>
            </div>
  
          </div>
          <div class="col-sm-4">
            <div class="footer-link">
              <h1>Quick Links</h1>
              <ul class="quick-links">
              <li><a href="#">Home</a></li>
              <li><a href="#">Student Login</a></li>
              <li><a href="#">Staff Login</a></li>
              <li><a href="Index.html">Departments</a></li></ul>
              <!--<li><a href="#">AIDS Department</a></li>
              <li><a href="#">MECHANICAL Department</a></li><li><a href="#">MECHATRONICS Department</a></li>
              <li><a href="#">ELECTRONICS Department</a></li><li><a href="#">ELECTRICAL Department</a></li>
              <li><a href="#">CIVIL Department</a></li><li><a href="#">AUTOMATION Department</a></li>-->
            </div>
  
          </div>
          <div class="col-sm-4">
            <div class="footer-contact">
              <h1>Contact Us</h1>
            <div class="contact-details">
              <p>Yadrav – Ichalkaranji – 416121<br>
                Tal- Shirol, Dist.- Kolhapur,<br>
                State – Maharashtra.<br>
                
                  </p>
                  <hr>
                  <div>
                    <p>
                      <i class="fa fa-phone"> &nbsp;&nbsp; Toll Free -1800-233-1419/</i><br>
                      <i class="fa fa-phone">&nbsp;&nbsp;  Landline -+91 (2322) 253000/01</i><br>
                      <i class="fa fa-envelope"> &nbsp;&nbsp;contact@sitcoe.org.in</i>
                    </p>
                  </div>
            </div>
             
            </div>
  
          </div>
  
        </div>
      </footer>
      <script src="assets/js/bootstrap.bundle.js"></script>
    </body>
</html>