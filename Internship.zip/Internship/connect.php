<?php 

$con= new mysqli('localhost','u138073963_interndb','Sit@34567','u138073963_interndb')or die("Could not connect to mysql".mysqli_error($con));

?>