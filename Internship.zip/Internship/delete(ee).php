<?php
include 'connect.php';
if(isset($_GET['deleteid'])){
	$ID=$_GET['deleteid'];

	$sql="delete from formee where ID=$ID";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		//echo "Deleted Successfully";
		header('location:display(ee).php');
	}
	else
	{
		die(mysqli_error($con));
	}
}
 


?>