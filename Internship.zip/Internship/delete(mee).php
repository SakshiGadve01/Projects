<?php
include 'connect.php';
if(isset($_GET['deleteid'])){
	$ID=$_GET['deleteid'];

	$sql="delete from formmee where ID=$ID";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		//echo "Deleted Successfully";
		header('location:display(mee).php');
	}
	else
	{
		die(mysqli_error($con));
	}
}
 


?>