<?php
include 'connect.php';
if(isset($_GET['deleteid'])){
	$ID=$_GET['deleteid'];

	$sql="delete from formrae where ID=$ID";
	$result=mysqli_query($con,$sql);
	if($result)
	{
		//echo "Deleted Successfully";
		header('location:display(rae).php');
	}
	else
	{
		die(mysqli_error($con));
	}
}
 


?>