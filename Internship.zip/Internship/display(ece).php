<?php
  include 'connect.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<title>Data Display</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">

</head>
<body>
<br><br><br>
<div class="container">
	
  
	<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col"> Sr no</th>
      <th scope="col"> Students Name</th>
      <th scope="col"> Mobile Number</th>
      <th scope="col"> PRN NUMBER</th>
      <th scope="col"> Class</th>
      <th scope="col"> Department</th>
      <th scope="col"> Email</th>
      <th scope="col"> Company Name</th>
      <th scope="col"> Location</th>
      <th scope="col"> Problem Statement</th>
      <th scope="col" style="padding-left: 80px;padding-right: 80px;"> Operations</th>
    </tr>
  </thead>
  <tbody>
  	<?php
         $sql = "Select * from formece ";
         $result = mysqli_query($con,$sql);
         if($result){
         	while($row=mysqli_fetch_assoc($result))
          {
         		$ID=$row['id'];
         		$s = $row['Student_Name'];
            $pn = $row['PhoneNumber'];
            $p = $row['prn'];
            $c = $row['class'];
            $d = $row['department'];
            $e = $row['email'];
            $co = $row['companyname'];
            $l = $row['location'];
            $ps = $row['ProblemStatement'];
         		echo '
         		<tr>
      				<th scope="row">'.$ID.'</th>
      				<td>'.$s.'</td>
      				<td>'.$pn.'</td>
      				<td>'.$p.'</td>
      				<td>'.$c.'</td>
              <td>'.$d.'</td>
              <td>'.$e.'</td>
              <td>'.$co.'</td>
              <td>'.$l.'</td>
              <td>'.$ps.'</td>
      			 <td>
      				<a href="update(ece).php?updateid='.$ID.'" class="text-light">
                 <button class="btn btn-primary">Update</button>
              </a>
      				<a href="delete(ece).php?deleteid='.$ID.'" class="text-light">
                  <button class="btn btn-danger">Delete</button>
              </a>
      				</td>

    			  </tr>';
         	}
         	
         }

  	?>
   



  </tbody>
</table>





</div>

</body>
</html>