 <?php

 $con=mysqli_connect('localhost','u138073963_interndb','Sit@34567','u138073963_interndb') or die("Connection Failed");
 
  $prn_no = $_POST['prn_no'];
  $password = $_POST['password'];
 
  $prn_no = stripcslashes($prn_no);
   $password = stripcslashes($password);

   $prn_no = mysqli_real_escape_string($con,$prn_no);
   $password = mysqli_real_escape_string($con,$password);


    $query = "Select * from student_loginee where prn_no='$prn_no' and password='$password'";
    $r= mysqli_query($con,$query);
    $row = mysqli_fetch_array($r,MYSQLI_ASSOC);
    $count =mysqli_num_rows($r);

    if($count==1)
    {
        echo "<script> window.location.assign('internshipform.php');</script>";
    }
    else
    {
        echo "LOGIN  NOT SUCCESFUL";
    }
  
 
 ?>