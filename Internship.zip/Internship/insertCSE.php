<?php

 $con=mysqli_connect('localhost','u138073963_interndb','Sit@34567','u138073963_interndb') or die("Connection Failed");
 
 if(isset($_POST['sb']))
 {
    $s = $_POST['Student_Name'];
    $pn = $_POST['PhoneNumber'];
    $p = $_POST['prn'];
    $c = $_POST['class'];
    $d = $_POST['department'];
    $e = $_POST['email'];
    $co = $_POST['companyname'];
    $l = $_POST['location'];
    $ps = $_POST['ProblemStatement'];


    $query = "INSERT INTO formcse(Student_Name,PhoneNumber,prn,class,department,email,companyname,location,ProblemStatement)VALUES('$s',
        '$pn','$p','$c','$d','$e','$co','$l','$ps')";
    $run = mysqli_query($con,$query);
    if($run){
        
         $msg = "SUccessful!";

    }
    else
    {
      die(mysqli_error($con));
    }
 }
 ?>
<script>
    alert('SUCCESSFULLY SUBMITTED');
</script>