-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 19, 2023 at 10:06 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `internship`
--

-- --------------------------------------------------------

--
-- Table structure for table `facultyloginaids`
--

CREATE TABLE `facultyloginaids` (
  `id` int(255) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `facultyloginaids`
--

INSERT INTO `facultyloginaids` (`id`, `user_name`, `password`) VALUES
(1, 'AIDS', 'AIDS');

-- --------------------------------------------------------

--
-- Table structure for table `facultylogince`
--

CREATE TABLE `facultylogince` (
  `id` int(255) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `facultylogincse`
--

CREATE TABLE `facultylogincse` (
  `id` int(255) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `facultylogincse`
--

INSERT INTO `facultylogincse` (`id`, `user_name`, `password`) VALUES
(1, 'CSE', 'CSE');

-- --------------------------------------------------------

--
-- Table structure for table `facultyloginece`
--

CREATE TABLE `facultyloginece` (
  `id` int(255) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `facultyloginee`
--

CREATE TABLE `facultyloginee` (
  `id` int(255) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `facultyloginme`
--

CREATE TABLE `facultyloginme` (
  `id` int(255) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `facultyloginmee`
--

CREATE TABLE `facultyloginmee` (
  `id` int(255) NOT NULL,
  `user_name` int(100) NOT NULL,
  `password` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `facultyloginrae`
--

CREATE TABLE `facultyloginrae` (
  `id` int(255) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `formaids`
--

CREATE TABLE `formaids` (
  `id` int(255) NOT NULL,
  `Student_Name` varchar(255) NOT NULL,
  `PhoneNumber` int(10) NOT NULL,
  `prn` int(10) NOT NULL,
  `class` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `companyname` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `ProblemStatement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `formce`
--

CREATE TABLE `formce` (
  `id` int(255) NOT NULL,
  `Student_Name` varchar(255) NOT NULL,
  `PhoneNumber` varchar(10) NOT NULL,
  `prn` varchar(10) NOT NULL,
  `class` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `companyname` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `ProblemStatement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `formcse`
--

CREATE TABLE `formcse` (
  `id` int(255) NOT NULL,
  `Student_Name` varchar(255) NOT NULL,
  `PhoneNumber` varchar(10) NOT NULL,
  `prn` varchar(10) NOT NULL,
  `class` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `companyname` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `ProblemStatement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `formcse`
--

INSERT INTO `formcse` (`id`, `Student_Name`, `PhoneNumber`, `prn`, `class`, `department`, `email`, `companyname`, `location`, `ProblemStatement`) VALUES
(1, 'demo name', '7894561230', '4563210', 'Btech', 'CSE', 'a@gmail.com', 'sit college', 'ichalkaranji', 'admission'),
(6, 'a', '1234567890', '1111111111', 'Btech', 'CSE', 'a@gmail.com', 'sit', 'yadrav', 'web development');

-- --------------------------------------------------------

--
-- Table structure for table `formece`
--

CREATE TABLE `formece` (
  `id` int(255) NOT NULL,
  `Student_Name` varchar(255) NOT NULL,
  `PhoneNumber` varchar(10) NOT NULL,
  `prn` varchar(10) NOT NULL,
  `class` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `companyname` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `ProblemStatement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `formee`
--

CREATE TABLE `formee` (
  `id` int(11) NOT NULL,
  `Student_Name` varchar(255) NOT NULL,
  `PhoneNumber` varchar(10) NOT NULL,
  `prn` varchar(10) NOT NULL,
  `class` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `companyname` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `ProblemStatement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `formme`
--

CREATE TABLE `formme` (
  `id` int(255) NOT NULL,
  `Student_Name` varchar(255) NOT NULL,
  `PhoneNumber` varchar(10) NOT NULL,
  `prn` varchar(10) NOT NULL,
  `class` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `companyname` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `ProblemStatement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `formmee`
--

CREATE TABLE `formmee` (
  `id` int(255) NOT NULL,
  `Student_Name` varchar(255) NOT NULL,
  `PhoneNumber` varchar(10) NOT NULL,
  `prn` varchar(10) NOT NULL,
  `class` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `companyname` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `ProblemStatement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `formrae`
--

CREATE TABLE `formrae` (
  `id` int(255) NOT NULL,
  `Student_Name` varchar(255) NOT NULL,
  `PhoneNumber` varchar(10) NOT NULL,
  `prn` varchar(10) NOT NULL,
  `class` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `companyname` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `ProblemStatement` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `user_name`, `password`) VALUES
(1, 'abc@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `student_loginaids`
--

CREATE TABLE `student_loginaids` (
  `id` int(255) NOT NULL,
  `prn_no` int(10) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_loginaids`
--

INSERT INTO `student_loginaids` (`id`, `prn_no`, `password`) VALUES
(1, 1111111111, '1111111111');

-- --------------------------------------------------------

--
-- Table structure for table `student_logince`
--

CREATE TABLE `student_logince` (
  `id` int(255) NOT NULL,
  `prn_no` int(10) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student_logincse`
--

CREATE TABLE `student_logincse` (
  `id` int(255) NOT NULL,
  `prn_no` int(10) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_logincse`
--

INSERT INTO `student_logincse` (`id`, `prn_no`, `password`) VALUES
(1, 2103010003, '2103010003');

-- --------------------------------------------------------

--
-- Table structure for table `student_loginece`
--

CREATE TABLE `student_loginece` (
  `id` int(255) NOT NULL,
  `prn_no` int(10) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student_loginee`
--

CREATE TABLE `student_loginee` (
  `id` int(255) NOT NULL,
  `prn_no` int(10) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student_loginme`
--

CREATE TABLE `student_loginme` (
  `id` int(255) NOT NULL,
  `prn_no` int(10) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student_loginmee`
--

CREATE TABLE `student_loginmee` (
  `id` int(255) NOT NULL,
  `prn_no` int(10) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student_loginrae`
--

CREATE TABLE `student_loginrae` (
  `id` int(255) NOT NULL,
  `prn_no` int(10) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `facultyloginaids`
--
ALTER TABLE `facultyloginaids`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facultylogince`
--
ALTER TABLE `facultylogince`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facultylogincse`
--
ALTER TABLE `facultylogincse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facultyloginece`
--
ALTER TABLE `facultyloginece`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facultyloginee`
--
ALTER TABLE `facultyloginee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facultyloginme`
--
ALTER TABLE `facultyloginme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facultyloginmee`
--
ALTER TABLE `facultyloginmee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facultyloginrae`
--
ALTER TABLE `facultyloginrae`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `formaids`
--
ALTER TABLE `formaids`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `formce`
--
ALTER TABLE `formce`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `formcse`
--
ALTER TABLE `formcse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `formece`
--
ALTER TABLE `formece`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `formee`
--
ALTER TABLE `formee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `formme`
--
ALTER TABLE `formme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `formmee`
--
ALTER TABLE `formmee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `formrae`
--
ALTER TABLE `formrae`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_loginaids`
--
ALTER TABLE `student_loginaids`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_logince`
--
ALTER TABLE `student_logince`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_logincse`
--
ALTER TABLE `student_logincse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_loginece`
--
ALTER TABLE `student_loginece`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_loginee`
--
ALTER TABLE `student_loginee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_loginme`
--
ALTER TABLE `student_loginme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_loginmee`
--
ALTER TABLE `student_loginmee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_loginrae`
--
ALTER TABLE `student_loginrae`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `facultyloginaids`
--
ALTER TABLE `facultyloginaids`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `facultylogince`
--
ALTER TABLE `facultylogince`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `facultylogincse`
--
ALTER TABLE `facultylogincse`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `facultyloginece`
--
ALTER TABLE `facultyloginece`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `facultyloginee`
--
ALTER TABLE `facultyloginee`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `facultyloginme`
--
ALTER TABLE `facultyloginme`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `facultyloginmee`
--
ALTER TABLE `facultyloginmee`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `facultyloginrae`
--
ALTER TABLE `facultyloginrae`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `formaids`
--
ALTER TABLE `formaids`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `formce`
--
ALTER TABLE `formce`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `formcse`
--
ALTER TABLE `formcse`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `formece`
--
ALTER TABLE `formece`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `formee`
--
ALTER TABLE `formee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `formme`
--
ALTER TABLE `formme`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `formmee`
--
ALTER TABLE `formmee`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `formrae`
--
ALTER TABLE `formrae`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student_loginaids`
--
ALTER TABLE `student_loginaids`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student_logince`
--
ALTER TABLE `student_logince`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_logincse`
--
ALTER TABLE `student_logincse`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student_loginece`
--
ALTER TABLE `student_loginece`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_loginee`
--
ALTER TABLE `student_loginee`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_loginme`
--
ALTER TABLE `student_loginme`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_loginmee`
--
ALTER TABLE `student_loginmee`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_loginrae`
--
ALTER TABLE `student_loginrae`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
