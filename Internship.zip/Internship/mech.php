<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SIT Internship</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/fontawesome/css/all.css">
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <center>
    <div class="card mb-3" style="max-width: 1500px;" id="tit1">
        <div class="row g-0">
          <div class="col-md-4">
            <img src="logo.png" class="img-fluid rounded-start" alt="..."id="img1" style="background-color: orange;">
          </div>
          <div class="col-md-8">
            <div class="card-body">
              <h5 class="card-title">SHARAD INSTITUTE OF TECHNOLOGY COLLEGE OF ENGINEERING</h5>
              <p class="card-text">An Autonomous Institute 
                NBA Accredited Programmes. An ‘A’ Grade Institute Accredited By NAAC, An ISO 9001:2015 Accredited Institute.  
                Recognized u/s 2(f) & 12(B) Of The UGC Act 1956</p>
            </div>
          </div>
        </div>
      </div></center>
      <section id="dash" class="dashclass">
        <div class="row row-cols-1 row-cols-md-2 g-4">
            <div class="col">
              <div class="card">
                <img src="student.png" class="card-img-top" alt="..." width="50px"height="250">
                <div class="card-body">
                  <a href="studlogin(ME).php" style="text-decoration: none;"><center><h3 class="card-title">Student Login</center></h3></a>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card">
                <img src="teacher.png" class="card-img-top" alt="..."width="50px"height="250">
                <div class="card-body">
                  <a href="faclogin(ME).php"style="text-decoration: none;"><center><h3 class="card-title">Faculty Login</h3></a></center>
                </div>
              </div>
            </div>
      </section>
      </body>
      </html>