
 <?php

 $con=mysqli_connect('localhost','u138073963_interndb','Sit@34567','u138073963_interndb') or die("Connection Failed");
 
 if(isset($_POST['sb']))
 {
    $prn_no = $_POST['prn_no'];
    $password = $_POST['password'];

    $query = "INSERT INTO student_loginme(prn_no,password)VALUES('$prn_no','$password')";
    $run = mysqli_query($con,$query);
    if($run){
        
         $msg = "Successful!";

    }
    else
    {
      die(mysqli_error($con));
    }
 }
 ?>
<script>
    alert('SUCCESSFULLY SUBMITTED');
</script>