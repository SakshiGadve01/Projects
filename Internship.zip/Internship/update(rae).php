<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>INTERNSHIP FORM</title>
  <meta name="description" content="In this tutorial you will learn how to html code for registration form with Javascript validation. We will also create form with nice css styling." />
    <meta name="author" content="Codeconvey" />
    <!--Only for demo purpose - no need to add.-->
    <link rel="stylesheet" type="text/css" href="demo.css" />
  <link rel="stylesheet" href="css/formstyle.css">
</head>

<?php
 
 include 'connect.php';
 

 if(!empty($_GET['updateid']))
 {

 $id=$_GET['updateid'];

 $sql="Select * from formrae where id=$id";
 $result = mysqli_query($con,$sql);
 $row = mysqli_fetch_assoc($result);
 $s = $row['Student_Name'];
 $pn = $row['PhoneNumber'];
 $p = $row['prn'];
 $c = $row['class'];
 $d = $row['department'];
 $e = $row['email'];
 $co = $row['companyname'];
 $l = $row['location'];
 $ps = $row['ProblemStatement'];
}

 if(isset($_POST['sb']))
 {
            $s = $_POST['Student_Name'];
            $pn = $_POST['PhoneNumber'];
            $p = $_POST['prn'];
            $c = $_POST['class'];
            $d = $_POST['department'];
            $e = $_POST['email'];
            $co = $_POST['companyname'];
            $l = $_POST['location'];
            $ps = $_POST['ProblemStatement'];
            $id=$_POST['idvalue'];

    $query = "update formrae set Student_Name='$s',PhoneNumber='$pn',prn='$p',class='$c',department='$d',email='$e',companyname='$co',location='$l',ProblemStatement='$ps' where id='$id'";

    echo $query;
    $result = mysqli_query($con,$query);
    if($result){
       //echo "Updated Successfully";
      header('location:display(rae).php');

    }
    else
    {
      die(mysqli_error($con));
    }
 }
?>
<body>
    <center>
        <div class="card mb-3" style="max-width: 1500px;" id="tit1">
            <div class="row g-0">
              <div class="col-md-4">
                <img src="sitlogo.webp" class="img-fluid rounded-start" alt="..."id="img1" style="height: 100px;">
              </div>
              <div class="col-md-8">
                <div class="card-body" id="tit2">
                  <h5 class="card-title">SHARAD INSTITUTE OF TECHNOLOGY COLLEGE OF ENGINEERING</h5>
                  <p class="card-text">An Autonomous Institute NBA Accredited Programmes. An ‘A’ Grade Institute Accredited By NAAC, An ISO 9001:2015 Accredited Institute.  
                    Recognized u/s 2(f) & 12(B) Of The UGC Act 1956</p>
                </div>
              </div>
            </div>
          </div></center>
    

<header class="ScriptHeader">
    <div class="rt-container">
      <div class="col-rt-12">
          <div class="rt-heading">
              <h1>Internship Details</h1>
            </div>
        </div>
    </div>
</header>

<section>
    <div class="rt-container">
          <div class="col-rt-12">
               
               <div class="form-container">
                <form name="internshipForm" method="post">
                  <label for="studName">Student Name *</label>
                  <input type="text" id="Student_Name" name="Student_Name" value=<?php echo $s;?>>

                  <input type="hidden" id="idvalue" name="idvalue" value=<?php echo $id;?>>

                  <label for="PhoneNumber">Mobile Number *</label>
                  <input type="text" id="PhoneNumber" name="PhoneNumber" maxlength="10" pattern=".{9,}"   required title="9 characters length" value=<?php echo $pn;?>>

                  <label for="prn">PRN Number *</label>
                  <input type="text" id="prn" name="prn" value=<?php echo $p;?>>

                  <label for="class">Class *</label>
                  <input type="text" id="class" name="class" value=<?php echo $c;?>>

                  <label for="department">Department *</label>
                  <input type="text" id="department" name="department" value=<?php echo $d;?>>

                  <label for="email">E-mail address *</label>
                  <input type="text" id="email" name="email" value=<?php echo $e;?>>

                  <label for="companyname">Company Name *</label>
                  <input type="text" id="companyname" name="companyname" value=<?php echo $co;?>>

                  <label for="location">Location *</label>
                  <input type="text" id="location" name="location" value=<?php echo $l;?>>

                  <label for="ProblemStatement">Problem Statement *</label>
                  <input type="text" id="ProblemStatement" name="ProblemStatement" value=<?php echo $ps;?>>

                  <center>
                  <button type="submit" name="sb" class="registerbtn" style="border-radius:25px;width:100%;height:40px;background: orange;" ><b> UPDATE</b></button></center><br><br>

 
                  
                 </form>





                 </div>
              </div>
  
    </div>
    </div>
 
</section>

</body>
</html>